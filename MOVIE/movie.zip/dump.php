<?php
echo "working";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<script type="text/javascript">
	var empty = ["1","2","3"];
	<?php $seat1 = "document.write(empty[0])";
	echo $seat1;
	?>

</script>
</body>
</html>

